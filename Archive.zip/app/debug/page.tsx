"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function DebugPage() {
  const [apiStatus, setApiStatus] = useState<any>(null)
  const [testResponse, setTestResponse] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    checkApiKey()
  }, [])

  const checkApiKey = async () => {
    try {
      const response = await fetch("/api/check")
      const data = await response.json()
      setApiStatus(data)
    } catch (err) {
      setError("Error checking API key")
      console.error(err)
    }
  }

  const testApi = async () => {
    setIsLoading(true)
    setError(null)
    try {
      const response = await fetch("/api/claude", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [
            {
              role: "user",
              content: "Hello, can you give me a quick test response?",
            },
          ],
        }),
      })

      if (!response.ok) {
        throw new Error(`API returned ${response.status}`)
      }

      const data = await response.json()
      setTestResponse(data)
    } catch (err) {
      setError(`Test failed: ${err instanceof Error ? err.message : "Unknown error"}`)
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10 px-4">
      <h1 className="text-2xl font-bold mb-6">Debug Page</h1>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>API Key Status</CardTitle>
          </CardHeader>
          <CardContent>
            {apiStatus ? (
              <div>
                <p>Anthropic API Key: {apiStatus.hasAnthropicKey ? "✅ Set" : "❌ Not set"}</p>
                <p>Key starts with: {apiStatus.keyFirstChars}</p>
              </div>
            ) : (
              <p>Loading...</p>
            )}
            <Button onClick={checkApiKey} className="mt-4">
              Refresh
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Test API</CardTitle>
          </CardHeader>
          <CardContent>
            <Button onClick={testApi} disabled={isLoading} className="mb-4">
              {isLoading ? "Testing..." : "Test API Connection"}
            </Button>

            {error && <div className="p-3 bg-red-50 text-red-700 rounded mb-4">{error}</div>}

            {testResponse && (
              <div className="p-3 bg-green-50 text-green-700 rounded">
                <p className="font-bold">Response received:</p>
                <p className="mt-2">{testResponse.content}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
