"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Loader2, Send, Heart, Sun, Moon } from "lucide-react"
import { cn } from "@/lib/utils"

// Define message type
type Message = {
  id: string
  role: "user" | "assistant"
  content: string
}

export default function Home() {
  // State for messages and input
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Hi there! I'm Florence, your caring companion. How are you feeling today?",
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [theme, setTheme] = useState<"light" | "dark">("light")

  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages])

  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value)
  }

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)
    setError(null)

    try {
      console.log("Sending message to API...")

      const response = await fetch("/api/claude", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [...messages, userMessage].map((msg) => ({
            role: msg.role,
            content: msg.content,
          })),
        }),
      })

      console.log("API response status:", response.status)

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        console.error("API error:", errorData)
        throw new Error(`API error: ${response.status}`)
      }

      const data = await response.json()
      console.log("API response data:", data)

      // Add assistant response
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          role: "assistant",
          content: data.content || "I'm sorry, I couldn't generate a response.",
        },
      ])
    } catch (err) {
      console.error("Error in chat:", err)
      setError(`Error: ${err instanceof Error ? err.message : "Unknown error"}`)

      // Add error message as assistant
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          role: "assistant",
          content:
            "I'm having trouble connecting. Please check the console for errors and make sure your API key is set correctly.",
        },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light")
  }

  return (
    <main
      className={cn(
        "flex min-h-screen flex-col items-center justify-between p-4 md:p-24 transition-colors duration-300",
        theme === "light" ? "bg-gradient-to-b from-purple-50 to-white" : "bg-gradient-to-b from-gray-900 to-gray-800",
      )}
    >
      <Card
        className={cn(
          "w-full max-w-3xl shadow-lg border-purple-100 transition-colors duration-300",
          theme === "dark" && "bg-gray-800 border-gray-700",
        )}
      >
        <CardHeader
          className={cn(
            "bg-purple-500 text-white rounded-t-lg flex justify-between items-center",
            theme === "dark" && "bg-purple-800",
          )}
        >
          <CardTitle className="flex items-center gap-2">
            <Avatar className="h-8 w-8 bg-white">
              <AvatarFallback className="text-purple-600">F</AvatarFallback>
            </Avatar>
            Florence - Your Caring Companion
          </CardTitle>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="text-white hover:bg-purple-400 hover:bg-opacity-30"
          >
            {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
          </Button>
        </CardHeader>
        <CardContent className={cn("p-0", theme === "dark" && "bg-gray-800")}>
          <ScrollArea className="h-[60vh] p-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`mb-4 flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.role !== "user" && (
                  <Avatar className="h-8 w-8 mr-2 mt-1 bg-purple-100">
                    <AvatarFallback className="text-purple-600">F</AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`px-4 py-2 rounded-lg max-w-[80%] ${
                    message.role === "user"
                      ? "bg-purple-500 text-white rounded-tr-none"
                      : "bg-gray-100 text-gray-800 rounded-tl-none"
                  }`}
                >
                  {message.content}
                </div>
                {message.role === "user" && (
                  <Avatar className="h-8 w-8 ml-2 mt-1 bg-purple-500">
                    <AvatarFallback>You</AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />

            {error && <div className="p-2 mt-2 text-sm text-red-500 bg-red-50 rounded">{error}</div>}
          </ScrollArea>
        </CardContent>
        <CardFooter
          className={cn(
            "p-4 border-t transition-colors duration-300",
            theme === "dark" && "border-gray-700 bg-gray-800",
          )}
        >
          <form onSubmit={handleSubmit} className="flex w-full gap-2">
            <Input
              value={input}
              onChange={handleInputChange}
              placeholder="Tell me how you're feeling today..."
              className={cn(
                "flex-1 transition-colors duration-300",
                theme === "light"
                  ? "border-purple-200 focus-visible:ring-purple-500"
                  : "bg-gray-700 border-gray-600 text-white focus-visible:ring-purple-400",
              )}
              disabled={isLoading}
            />
            <Button
              type="submit"
              disabled={isLoading || !input.trim()}
              className={cn(
                "transition-colors duration-300",
                theme === "light" ? "bg-purple-500 hover:bg-purple-600" : "bg-purple-700 hover:bg-purple-800",
              )}
            >
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </form>
        </CardFooter>
      </Card>
      <div
        className={cn(
          "mt-4 text-center text-sm opacity-70 transition-colors duration-300",
          theme === "dark" && "text-gray-400",
        )}
      >
        <p className="flex items-center justify-center gap-1">
          Made with <Heart className="h-3 w-3 text-red-500 fill-red-500" /> for healthcare heroes
        </p>
      </div>
    </main>
  )
}
