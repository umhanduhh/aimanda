import { NextResponse } from "next/server"

// This route is for checking if the environment variables are set
export async function GET() {
  return NextResponse.json({
    hasOpenAI: !!process.env.OPENAI_API_KEY,
    hasAnthropic: !!process.env.ANTHROPIC_API_KEY,
  })
}
