import { NextResponse } from "next/server"

// This endpoint checks if the API key is set
export async function GET() {
  return NextResponse.json({
    hasAnthropicKey: !!process.env.ANTHROPIC_API_KEY,
    keyFirstChars: process.env.ANTHROPIC_API_KEY ? `${process.env.ANTHROPIC_API_KEY.substring(0, 5)}...` : "Not set",
  })
}
