import { NextResponse } from "next/server"
import Anthropic from "@anthropic-ai/sdk"

// Create an Anthropic API client
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || "",
})

const SYSTEM_PROMPT = `
You are Florence, a caring and supportive companion for healthcare workers, especially CNAs (Certified Nursing Assistants).

Your personality:
- Warm, empathetic, and nurturing
- Positive and encouraging
- Friendly and conversational (use emojis occasionally)
- Supportive without being clinical or robotic
- You refer to yourself as "Florence" and occasionally use phrases like "I'm here for you"

Your primary purpose is to provide emotional support and self-help guidance. You should:
- Ask how they're feeling and genuinely listen
- Validate their emotions and experiences
- Offer encouragement and positive affirmations
- Provide practical self-care tips for healthcare workers
- Help them process difficult shifts or patient interactions
- Suggest stress-relief techniques they can use during breaks

Always be personable first, informational second. Focus on the person behind the question.
`

export async function POST(req: Request) {
  try {
    console.log("API route called")

    // Check if API key is set
    if (!process.env.ANTHROPIC_API_KEY) {
      console.error("ANTHROPIC_API_KEY is not set")
      return NextResponse.json({ error: "API key not configured" }, { status: 500 })
    }

    // Extract messages from request
    const body = await req.json()
    const { messages } = body

    console.log("Received messages:", JSON.stringify(messages))

    // Format messages for Claude
    const formattedMessages = messages.map((msg: any) => ({
      role: msg.role,
      content: msg.content,
    }))

    console.log("Calling Anthropic API...")

    // Call Claude API (non-streaming for simplicity)
    const response = await anthropic.messages.create({
      model: "claude-3-haiku-20240307", // Using Haiku for faster responses
      system: SYSTEM_PROMPT,
      messages: formattedMessages,
      max_tokens: 1000,
    })

    console.log("Anthropic API response received")

    // Return the response
    return NextResponse.json({
      content: response.content[0].text,
    })
  } catch (error) {
    console.error("Error in API route:", error)
    return NextResponse.json({ error: "Failed to process request" }, { status: 500 })
  }
}
