"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ApiSelector } from "@/components/api-selector"
import { useRouter } from "next/navigation"

export default function SettingsPage() {
  const router = useRouter()
  const [openaiKey, setOpenaiKey] = useState("")
  const [anthropicKey, setAnthropicKey] = useState("")
  const [selectedApi, setSelectedApi] = useState("/api/chat")

  const handleSave = () => {
    // In a real app, you'd securely store these keys
    // For demo purposes, we're just logging them
    console.log("API Keys saved")
    console.log("Selected API:", selectedApi)

    // In a production app, you'd use a secure method to store these
    // like server-side environment variables or a secure vault

    router.push("/")
  }

  return (
    <div className="container mx-auto py-10">
      <div className="max-w-md mx-auto space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>API Settings</CardTitle>
            <CardDescription>Configure your AI provider API keys</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="openai-key">OpenAI API Key</Label>
              <Input
                id="openai-key"
                type="password"
                value={openaiKey}
                onChange={(e) => setOpenaiKey(e.target.value)}
                placeholder="sk-..."
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="anthropic-key">Anthropic API Key</Label>
              <Input
                id="anthropic-key"
                type="password"
                value={anthropicKey}
                onChange={(e) => setAnthropicKey(e.target.value)}
                placeholder="sk-ant-..."
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleSave} className="w-full">
              Save Settings
            </Button>
          </CardFooter>
        </Card>

        <ApiSelector onSelect={setSelectedApi} defaultApi={selectedApi} />

        <div className="text-center text-sm text-gray-500">
          <p>Your API keys are stored securely and are only used to communicate with the AI providers.</p>
        </div>
      </div>
    </div>
  )
}
