"use client"

import { useState } from "react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"


interface ApiSelectorProps {
  onSelect: (api: string) => void
  defaultApi?: string
}


export function ApiSelector({ onSelect, defaultApi = "/api/chat-claude" }: ApiSelectorProps) {
  const [selectedApi, setSelectedApi] = useState(defaultApi)

  const handleChange = (value: string) => {
    setSelectedApi(value)
    onSelect(value)
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Choose AI Provider</CardTitle>
        <CardDescription>Select which AI model Florence will use to chat with you</CardDescription>
      </CardHeader>
      <CardContent>
        <RadioGroup defaultValue={selectedApi} onValueChange={handleChange}>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="/api/chat-claude" id="claude" />
            <Label htmlFor="claude" className="cursor-pointer">
              Anthropic (Claude)
            </Label>
          </div>
        </RadioGroup>
      </CardContent>
    </Card>
  )
}
